#ifndef dealer_h
#define dealer_h

#include "card.h"
#include "deck.h"

class dealer{
	public:
	card cur_card;
	int cur_hand_val;
	int bust;
	int bj;

//	public:

	dealer();	
	int play(deck&);
	void get_first(deck&);
	int get_card(deck&);
};

#endif
