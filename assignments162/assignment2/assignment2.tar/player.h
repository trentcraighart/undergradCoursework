#ifndef player_h
#define player_h

#include "card.h"
#include "deck.h"
#include <iostream>

class player{
	public:

	card cur_car;
	int cur_bet;
	int cur_hand_val;
	int bust;
	int bj;
	int player_number;
	int tot_money;

	player();
	player(int player_num, int total);

	void get_card(deck&);
	int test_for_int();
	void get_start_hand(deck&);
	void make_bet(int&);
};

#endif
