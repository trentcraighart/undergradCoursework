#ifndef deck_h
#define deck_h

#include "card.h"
#include <string>

class deck{
	private:
//	public:

	card gdeck [];
	int cards_left;


	public:
	deck();
	void pop_cards();
	void shuffle();
	card draw_card();
	~deck();
};

#endif
