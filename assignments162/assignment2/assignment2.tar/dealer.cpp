#include "dealer.h"

using namespace std;

dealer::dealer(){
	card cur_card;
	cur_card.value = 0;
	cur_hand_val = 0;
	bust = 0;
	bj = 0;
}

void dealer::get_first(deck& gdeck){
	cur_hand_val = get_card(gdeck);
}

int dealer::play(deck& gdeck){
	while(cur_hand_val < 16){
		cur_hand_val = cur_hand_val + get_card(gdeck);
	}
}

int dealer::get_card(deck& gdeck){
	int opt = 0;
	cout << "The dealer drew" << endl;
	cur_card = gdeck.draw_card();
	if(cur_card.value == 1){
		if(cur_hand_val <= 11){
			cur_hand_val = cur_hand_val + 1;
		}else{
			cur_hand_val = cur_hand_val +11;
		}
	}else{
		cur_hand_val = cur_hand_val + cur_card.value;
	}
}
