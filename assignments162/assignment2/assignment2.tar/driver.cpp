/****************
 *Program: blackjack.exe
 *Author: Trent Vasquez
 *Date: 04/20/2016
 *Description: Plays blackjack
****************/


#include <iostream>
#include <cstdlib>
#include <string>
#include <vector>

#include "deck.h"
#include "card.h"
#include "player.h"
#include "dealer.h"
#include "game.h"

using namespace std;

int main(){
	srand(time(NULL));
	struct card exe;
	player player_test(0, 0);
	cout << "How many players: ";
	int cat, dog;
	cin >> cat;
	dog = cat;
	
	vector<player> myvector;
	for(int i=0; i<cat; i++){
		player newplayer(i, 10);
		myvector.push_back(newplayer);
	}
	cout << dog;
	deck bj_deck;
	bj_deck.pop_cards();
	game bj_game(cat, myvector);
	string play = "y";
	do{
		bj_game.game_round(myvector, bj_deck, dog);
		cout << "Do you want to play another round?(n)-quit" << endl;
		cin >> play;
	}while(play == "n");	


	return 0;
}

