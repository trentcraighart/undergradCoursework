#ifndef game_h
#define game_h


#include "card.h"
#include "deck.h"
#include "player.h"
#include "dealer.h"
#include <vector>

using namespace std;

class game{
	private:
	int num_players;
	deck bj_deck;
	dealer bj_dealer;
	vector<player> vec;

	public:
	game(int, vector<player>& vec);
	void game_round(vector<player>& vec, deck&, int);

	
};

#endif
