#include <iostream>
#include <cstdlib>

using namespace std;

//prototypes
int get_int();
