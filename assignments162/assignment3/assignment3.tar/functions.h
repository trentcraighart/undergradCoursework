#ifndef functions_h
#define functions_h

#include <iostream>
#include <cstdlib>
#include <string>

using namespace std;

//prototypes

void buy_animal(Zoo&);
int get_int();

#endif
