#include "tiger.h"

Tiger::Tiger(){
	age = 3;
	num_baby = 1;
	price = 10000;
	food_mult = 5;
	pay_off = 1000;	
}

Tiger::Tiger(int age){
	this->age = age;
	num_baby = 1;
	price = 10000;
	food_mult = 5;
	pay_off = 1000;
}
