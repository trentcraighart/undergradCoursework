#ifndef bear_h
#define bear_h

#include "animal.h"

class Bear: public Animal{
	public:
	Bear();
	Bear(int);
};

#endif
