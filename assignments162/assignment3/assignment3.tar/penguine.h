#ifndef punguine_h
#define penguine_h

#include "animal.h"

class Penguine : public Animal{
	public:
	Penguine();
	Penguine(int);
};

#endif
