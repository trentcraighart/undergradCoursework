#ifndef high_score_h
#define high_score_h

class High_Score{
	private:
	int score;
	public:
	void print_score();
	void write_score(int);
};
#endif
