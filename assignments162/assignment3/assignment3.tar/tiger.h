#ifndef tiger_h
#define tiger_h

#include "animal.h"

class Tiger: public Animal{
	public:
	Tiger();
	Tiger(int);
};

#endif
