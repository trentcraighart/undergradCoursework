// Server side C/C++ program to demonstrate Socket programming
// Scott Merrill & Trent Vasquez
//Network Resource: https://www.geeksforgeeks.org/socket-programming-cc/
#include <unistd.h>
#include <stdio.h>
#include <sys/socket.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <string.h>
#include <time.h>
#include <openssl/sha.h>

#define PORT 40400


//Globals used
int BIT_LEN;

void gen_random(char *s, const int len) {
    srand(time(NULL));
    int wait = rand() % 1000 + 1;
    usleep(wait);
    static const char alphanum[] =
        "0123456789"
        "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        "abcdefghijklmnopqrstuvwxyz";
    int i;
    for (i = 0; i < len; ++i) {
        s[i] = alphanum[rand() % (sizeof(alphanum) - 1)];
    }

    s[len] = 0;
}

int main(int argc, char const *argv[])
{
    int server_fd, new_socket, valread;
    struct sockaddr_in address;
    int opt = 1;
    int addrlen = sizeof(address);
    char buffer[1024] = {0};
    char buffer2[BIT_LEN];
    char *hello = "Hello from server";
    char sol[BIT_LEN];
    srand(time(NULL));

    // Creating socket file descriptor
    if ((server_fd = socket(AF_INET, SOCK_STREAM, 0)) == 0)
    {
        perror("socket failed");
        exit(EXIT_FAILURE);
    }
      
    // Forcefully attaching socket to the port 8080
    if (setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR | SO_REUSEPORT,
                                                  &opt, sizeof(opt)))
    {
        perror("setsockopt");
        exit(EXIT_FAILURE);
    }
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port = htons( PORT );
      
    // Forcefully attaching socket to the port 8080
    if (bind(server_fd, (struct sockaddr *)&address, 
                                 sizeof(address))<0)
    {
        perror("bind failed");
        exit(EXIT_FAILURE);
    }
    if (listen(server_fd, 3) < 0)
    {
        perror("listen");
        exit(EXIT_FAILURE);
    }


    /******** Interface ***********/
    int diff = 1;
    printf("***** Server Starting up! ******\n");
    printf("Choose Puzzle bit difficulty:\n[1] - 8 bit\n[2] - 16 bit\n[3] - 20 bit\n[4] - 32 bit\n");
    scanf("%i",&diff);
    if(diff == 1){
        BIT_LEN = 2;
        printf("Your difficulty is %i bits\n\n",BIT_LEN*4);
    }
    else if(diff == 2){
        BIT_LEN = 4;
        printf("Your difficulty is %i bits\n\n",BIT_LEN*4);
    }
    else if(diff == 3){
        BIT_LEN = 5;
        printf("Your difficulty is %i bits\n\n",BIT_LEN*4);
    }
    else if(diff == 4){
        BIT_LEN = 8;
        printf("Your difficulty is %i bits\n\n",BIT_LEN*4);
    }
    else{
        printf("Error with diff\n");
        return 0;
    }  

        /********          Wait for connection request          *********/
    while (1){  
        if ((new_socket = accept(server_fd, (struct sockaddr *)&address, 
                           (socklen_t*)&addrlen))<0)
        {
            perror("accept");
            exit(EXIT_FAILURE);
        }
      

    /********          Read connection request           *********/
        valread = read( new_socket , buffer, 1024);
        printf("%s\n",buffer );

    /********          Generate/Send Puzzle           *********/
        char test[BIT_LEN]; //seed the puzzle (static at the moment)
        gen_random(test,BIT_LEN);

        // Create hash
        unsigned char digest[SHA_DIGEST_LENGTH];
        SHA((unsigned char*)&test, strlen(test), (unsigned char*)&digest);    
     
        char mdString[SHA_DIGEST_LENGTH*2+1];
        int i;
        for(i = 0; i < SHA_DIGEST_LENGTH; i++)
             sprintf(&mdString[i*2], "%02x", (unsigned int)digest[i]);
        //printf("digest: %s\n",&digest );
        int j;
        for(j=0; j<BIT_LEN; j++)
            sol[j] = mdString[j];



        send(new_socket , sol , BIT_LEN , 0 );
        printf("Puzzle sent\n");    

    /********          Wait to accept puzzle           *********/
        valread = read( new_socket , buffer2, BIT_LEN);   
        if(strcmp(buffer2,sol) == 0)
            printf("Solution Accepted\n\n");
        else
            printf("Solution  Rejected\n");      
    }
    return 0;
}