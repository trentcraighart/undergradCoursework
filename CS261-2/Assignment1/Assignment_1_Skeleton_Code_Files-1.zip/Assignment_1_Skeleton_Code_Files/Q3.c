/* CS261- Assignment 1 - Q.3*/
/* Name: 
 * Date: 
 * Solution description:
 */

#include <stdio.h>
#include <stdlib.h>



char toUpperCase(char ch){
  /*Convert ch to upper case, assuming it is in lower case currently*/

}

char toLowerCase(char ch){
  /*Convert ch to lower case, assuming it is in upper case currently*/                          

}

int stringLength(char s[]) {
   /*Return the length of the string*/
}


void camelCase(char* word){
	/*Convert to camelCase*/
	
	
}

int main(){

	/*Read the string from the keyboard*/
	
	
	/*Call camelCase*/
	
	
	/*Print the new string*/
	
	
	return 0;
}

